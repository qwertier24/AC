#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>

const double pi = acos(-1.0);

inline int RAN(){
	return rand() * RAND_MAX + rand();
}

void getZheng(int n){
	double ang = rand() * 2 * pi / RAND_MAX;
	double dx = 2 * pi / n;
	if(rand() & 1) dx = -dx;
	bool fir = true;
	int ddx = RAN() % 2000 - 1000, ddy = RAN() % 2000 - 1000;
	while(n--){
		printf(fir ? "%lf %lf" : " %lf %lf", (9000 * cos(ang)) + ddx, (9000 * sin(ang)) + ddy);
		fir = false;
		ang += dx;
	}
	printf("\n");
}

void getBZ(int n){
	double ang = rand() * 2 * pi / RAND_MAX;
	double dx = 2 * pi / n;
	if(rand() & 1) dx = -dx;
	bool fir = true;
	int ddx = RAN() % 2000 - 1000, ddy = RAN() % 2000 - 1000;
	while(n--){
		printf(fir ? "%lf %lf" : " %lf %lf", (8900 * cos(ang)) + ddx + RAN() % 100 - 50, (8900 * sin(ang)) + ddy + RAN() % 100 - 50);
		fir = false;
		ang += dx;
	}
	printf("\n");
}

void getRand(int n){
	double ang = rand() * 2 * pi / RAND_MAX;
	double dx = 2 * pi / n;
	if(rand() & 1) dx = -dx;
	bool fir = true;
	int ddx = RAN() % 2000 - 1000, ddy = RAN() % 2000 - 1000;
	while(n--){
		int cr = RAN() % 9000 + 1;
		printf(fir ? "%lf %lf" : " %lf %lf", cr * cos(ang) + ddx, cr * sin(ang) + ddy);
		fir = false;
		ang += dx;
	}
	printf("\n");
}

int main(){
	int MAX; scanf("%d", &MAX);
	srand(time(0));
	srand(rand()); srand(rand()); srand(rand()); srand(rand()); srand(rand());
	int TT = 10; printf("%d\n", TT);
	while(TT--){
		// int a = 0, b = 0;
		// while(a == b || a < 3 || b < 3){a = RAN() % MAX + 1; b = RAN() % MAX + 1;}
		// printf("%d %d\n", a, b);
		// getZheng(a); getZheng(b);
		
		// int a = 0;
		// while(a < 3) a = RAN() % MAX + 1;
		// printf("%d %d\n", a, a);
		// if(rand() & 1) getZheng(a), getRand(a); else getRand(a), getZheng(a);
		
		// if(rand() & 1){
			// int a = 0, b = 0;
			// while(a == b || a < 3 || b < 3){a = RAN() % MAX + 1; b = RAN() % MAX + 1;}
			// printf("%d %d\n", a, b);
			// getZheng(a); getZheng(b);
		// }else{
			// int a = 0;
			// while(a < 3) a = RAN() % MAX + 1;
			// printf("%d %d\n", a, a);
			// if(rand() & 1) getZheng(a), getRand(a); else getRand(a), getZheng(a);
		// }
		
		int a = 0, b = 0;
		while(a < 3 || b < 3 || a * 3 < b * 2 || b * 3 < a * 2){a = RAN() % MAX + 1; b = RAN() % MAX + 1;}
		if(rand() & 1) printf("%d %d\n", a, b), getBZ(a), getRand(b); else printf("%d %d\n", b, a), getRand(b), getBZ(a);
	}
	return 0;
}
