#include <cstdio>
#include <cmath>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)

int an, bn;
double x[100086], y[100086];
inline double sqr(double x){return x * x;}

int main(){
	int TT; scanf("%d", &TT);
	while(TT--){
		scanf("%d%d", &an, &bn);
		double S = 0; double C = 0;
		f(i, 1, an) scanf("%lf%lf", x + i, y + i);
		f(i, 2, an) S += x[i - 1] * y[i] - x[i] * y[i - 1], C += sqrt(sqr(x[i - 1] - x[i]) + sqr(y[i - 1] - y[i]));
		S += x[an] * y[1] - x[1] * y[an], C += sqrt(sqr(x[an] - x[1]) + sqr(y[an] - y[1]));
		double v1 = fabs(S) / (C * C);
		S = 0; C = 0;
		f(i, 1, bn) scanf("%lf%lf", x + i, y + i);
		f(i, 2, bn) S += x[i - 1] * y[i] - x[i] * y[i - 1], C += sqrt(sqr(x[i - 1] - x[i]) + sqr(y[i - 1] - y[i]));
		S += x[bn] * y[1] - x[1] * y[bn], C += sqrt(sqr(x[bn] - x[1]) + sqr(y[bn] - y[1]));
		double v2 = fabs(S) / (C * C);
		if(v1 > v2) printf("1\n"); else printf("2\n");
	}
	return 0;
}
