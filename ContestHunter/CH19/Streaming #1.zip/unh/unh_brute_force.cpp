#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)

int n, tim = 0, ans, cl, cr;
std::vector<int> adj[100086];
int dep[100086], W[100086];
inline void dfs(int x){
	for(std::vector<int>::iterator it = adj[x].begin(), end = adj[x].end(); it != end; ++it){
		dep[*it] = dep[x] + 1;
		dfs(*it);
	}
}
inline void efs(int x){
	if(dep[x] > cr) return;
	if(cl <= dep[x]) ans += W[x];
	for(std::vector<int>::iterator it = adj[x].begin(), end = adj[x].end(); it != end; ++it) efs(*it);
}

int main(){
#ifdef YJP
	freopen("con", "w", stderr);
#endif
	memset(W, 0, sizeof(W));
	int q;
	scanf("%d%d", &n, &q);
	f(i, 2, n){
		int cb; scanf("%d", &cb);
		adj[cb].push_back(i);
	}
	dep[1] = 1; dfs(1);
	while(q--){
		int cmd; scanf("%d", &cmd);
		if(cmd == 1){
			int w, e; scanf("%d%d", &w, &e);
			W[w] += e;
			printf("-1\n");
		}else{
			int w, e, r; scanf("%d%d%d", &w, &e, &r);
			cl = dep[w] + e; cr = dep[w] + r; ans = 0;
			efs(w);
			printf("%d\n", ans);
		}
	}
	return 0;
}
