#include <cstdio>
#include <cstdlib>
#include <vector>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)

template <class T>
inline T min(T x, T y){return x < y ? x : y;}

class SGT{
public:
	int sum;
	SGT *_lson, *_rson;
	inline SGT(){_lson = _rson = NULL; sum = 0;}
	inline SGT *lson();
	inline SGT *rson();
} pool1[3000000], *cp1 = pool1;
inline SGT *newSint(){
	return cp1++;
}
inline SGT *SGT::lson(){
	if(!_lson) _lson = newSint();
	return _lson;
}
inline SGT *SGT::rson(){
	if(!_rson) _rson = newSint();
	return _rson;
}
int xxxx = 0;
inline void inc(SGT *root, int l, int r, int x, int y){
	int m;
	while(l != r){
		root->sum += y;
		m = (l + r) >> 1;
		if(x <= m) root = root->lson(), r = m;
		else root = root->rson(), l = m + 1;
	}
	root->sum += y;
}
inline int sum(SGT *root, int l, int r, int x, int y){
	if(!root->sum) return 0;
	int m, ans = 0;
	for(;;){
		if(l == x && r == y) return ans + root->sum;
		m = (l + r) >> 1;
		if(y <= m) root = root->lson(), r = m;
		else if(x > m) root = root->rson(), l = m + 1;
		else{
			ans += sum(root->rson(), m + 1, r, m + 1, y);
			root = root->lson(); r = m; y = m;
		}
	}
}

int n, tim = 0, mdep = 0;
std::vector<int> adj[100086];
int id[100086], dep[100086], id2[100086];
inline void dfs(int x){
	id[x] = ++tim;
	for(std::vector<int>::iterator it = adj[x].begin(), end = adj[x].end(); it != end; ++it){
		dep[*it] = dep[x] + 1;
		if(dep[*it] > mdep) mdep = dep[*it];
		dfs(*it);
	}
	id2[x] = tim;
}

SGT tree[262144];
inline void sinc(int x, int y, int z){
	for(x += 131072; x; x >>= 1) inc(tree + x, 1, n, y, z);
}
inline int ssum(int x1, int x2, int y1, int y2){
	int ans = 0;
	for(x1 += 131071, x2 += 131073; x1 ^ x2 ^ 1; x1 >>= 1, x2 >>= 1){
		if(!(x1 & 1)) ans += sum(tree + (x1 ^ 1), 1, n, y1, y2);
		if(x2 & 1) ans += sum(tree + (x2 ^ 1), 1, n, y1, y2);
	}
	return ans;
}

int main(){
#ifdef YJP
	freopen("con", "w", stderr);
#endif
	int q;
	scanf("%d%d", &n, &q);
	f(i, 2, n){
		int cb; scanf("%d", &cb);
		adj[cb].push_back(i);
	}
	dep[1] = 1; dfs(1);
	while(q--){
		int cmd; scanf("%d", &cmd);
		if(cmd == 1){
			int w, e; scanf("%d%d", &w, &e);
			sinc(dep[w], id[w], e);
			printf("-1\n");
		}else{
			int w, e, r; scanf("%d%d%d", &w, &e, &r);
			printf("%d\n", ssum(min(dep[w] + e, n), min(dep[w] + r, n), id[w], id2[w]));
		}
	}
#ifdef YJP
	fprintf(stderr, "pn = %d\n", cp1 - pool1);
#endif
	return 0;
}
