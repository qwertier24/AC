#include <cstdio>
#include <cstring>
#include <algorithm>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)
#define h(x, y, z) for(int x = (y); x >= (z); --x)

int n, m;
int a[1086];
long long sufa[1086], suf[1086];
long long _dp[1086][56][56][56];
int npos[100086];
long long dp(int cn, int cmp, int chp, int dhp){
	long long &ans = _dp[cn][cmp][chp][dhp];
	if(ans != -1) return ans;
	if(cn > n) ans = 0;
	else if(a[cn] <= (chp << 1) + dhp) ans = dp(cn + 1, cmp, 0, dhp);
	else{
		if(!cmp){
			ans = (long long) (n + 1) * sufa[cn];
			ans -= (long long) dhp * (long long) (n + 2 - cn) * (long long) (n + 1 - cn) / 2LL;
			ans -= suf[cn];
			ans -= (long long) (chp << 1) * (long long) (n + 1 - cn);
		}else if(a[cn + 1] == (chp << 1) + dhp + 1){
			ans = (long long) (n + 1 - cn) + dp(cn, cmp - 1, chp, dhp + 1);
		}else{
			ans = n + 1 - cn;
			long long a1 = dp(cn, cmp - 1, chp + 1, dhp);
			long long a2 = dp(cn, cmp - 1, chp, dhp + 1);
			if(a1 < a2) ans += a1; else ans += a2;
		}
		printf("dp %d %d %d %d = %d\n", cn, cmp, chp, dhp, ans);
	}
	return ans;
}

int main(){
	scanf("%d%d", &n, &m);
	f(i, 1, n) scanf("%d", a + i);
	std::sort(a + 1, a + n + 1);
	int lnpos = 1;
	f(i, 1, n) for(; lnpos <= a[i]; lnpos++) npos[lnpos] = i;
	for(; lnpos <= 100008; lnpos++) npos[lnpos] = n;
	f(i, 1, n) suf[i] = (long long) i * (sufa[i] = a[i]);
	sufa[n + 1] = suf[n + 1] = 0;
	h(i, n, 1) suf[i] += suf[i + 1], sufa[i] += sufa[i + 1];
	memset(_dp, 0xff, sizeof(_dp));
	printf("%I64d\n", dp(1, m, 0, 0) - (long long) n);
	return 0;
}
