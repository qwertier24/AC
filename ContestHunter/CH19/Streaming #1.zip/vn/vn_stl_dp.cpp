#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
using std::map;
#define f(x, y, z) for(int x = (y); x <= (z); ++x)
#define h(x, y, z) for(int x = (y); x >= (z); --x)
inline int min(int x, int y){return x < y ? x : y;}
inline int max(int x, int y){return x > y ? x : y;}

int n, m;
int a[100086];
long long sufa[100086], suf[100086];
map<int, map<int, map<int, map<int, long long> > > > _dp;
int npos[100086];
int tt = 0;
inline long long dp(int cn, int cmp, int chp, int dhp){
	//printf("dp %d %d %d %d\n", cn, cmp, chp, dhp);
	if(_dp.count(cn)){
		map<int, map<int, map<int, long long> > > &tmp = _dp[cn];
		if(tmp.count(cmp)){
			map<int, map<int, long long> > &tmp2 = tmp[cmp];
			if(tmp2.count(chp)){
				map<int, long long> &tmp3 = tmp2[chp];
				if(tmp3.count(dhp)) return tmp3[dhp];
			}
		}
	}
#ifdef YJP
	++tt;
#endif
	long long &ans = _dp[cn][cmp][chp][dhp];
	if(cn > n) ans = 0;
	else if(a[cn] <= (chp << 1) + dhp) ans = dp(max(cn + 1, npos[dhp + 1]), cmp, 0, dhp);
	else if(!cmp){
		ans = (long long) (n + 1) * sufa[cn];
		ans -= (long long) dhp * (long long) (n + 2 - cn) * (long long) (n + 1 - cn) / 2LL;
		ans -= suf[cn];
		ans -= (long long) (chp << 1) * (long long) (n + 1 - cn);
	//printf("dp %d %d %d %d = %d\n", cn, cmp, chp, dhp, ans);
	}else if(a[cn + 1] == (chp << 1) + dhp + 1){
		ans = (long long) (n + 1 - cn) + dp(cn, cmp - 1, chp, dhp + 1);
	//printf("dp %d %d %d %d = %d\n", cn, cmp, chp, dhp, ans);
	}else{
		ans = n + 1 - cn;
		long long a1 = dp(cn, cmp - 1, chp + 1, dhp);
		long long a2 = dp(cn, cmp - 1, chp, dhp + 1);
		if(a1 < a2) ans += a1; else ans += a2;
	//printf("dp %d %d %d %d = %d\n", cn, cmp, chp, dhp, ans);
	}
	return ans;
}

int main(){
#ifdef YJP
	freopen("con", "w", stderr);
#endif
	scanf("%d%d", &n, &m);
	f(i, 1, n) scanf("%d", a + i);
	std::sort(a + 1, a + n + 1);
	int lnpos = 1;
	f(i, 1, n) for(; lnpos <= a[i]; lnpos++) npos[lnpos] = i;
	for(; lnpos <= 100008; lnpos++) npos[lnpos] = n + 1;
	f(i, 1, n) suf[i] = (long long) i * (sufa[i] = a[i]);
	sufa[n + 1] = suf[n + 1] = 0;
	h(i, n, 1) suf[i] += suf[i + 1], sufa[i] += sufa[i + 1];
	printf("%lld\n", dp(1, m, 0, 0) - (long long) n);
#ifdef YJP
	fprintf(stderr, "T = %d\n", tt);
#endif
	return 0;
}
