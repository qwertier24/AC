#include <cstdio>
#include <algorithm>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)

int n, m, cq = 0, cn = 1, h[100086];
long long ans = 0;

int main(){
	scanf("%d%d", &n, &m);
	f(i, 1, n) scanf("%d", h + i);
	std::sort(h + 1, h + n + 1);
	while(cn <= n && m > 0){
		int ch = h[cn] - cq;
		if(ch <= 0) ++cn;
		else if(cn + 1 < n || ch == 1) --m, ++cq, ans += (long long) (n + 1 - cn);
		else --m, h[cn] -= 2, ans += (long long) (n + 1 - cn);
	}
	if(cn <= n){
		long long csum = 0;
		f(i, cn, n) csum += (long long) h[i] - cq, ans += csum;
	}
	printf("%lld\n", ans - (long long) n);
	return 0;
}
