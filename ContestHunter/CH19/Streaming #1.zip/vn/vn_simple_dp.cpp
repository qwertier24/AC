#include <cstdio>
#include <cstring>
#include <algorithm>
#define f(x, y, z) for(int x = (y); x <= (z); ++x)

int n, m;
int a[56];
int _dp[56][56][56][56];
int dp(int cn, int cmp, int chp, int dhp){
	int &ans = _dp[cn][cmp][chp][dhp];
	if(ans != -1) return ans;
	if(cn > n) ans = 0;
	else if(chp <= 0) ans = dp(cn + 1, cmp, a[cn + 1] - dhp, dhp);
	else{
		if(!cmp){
			ans = n + 1 - cn + dp(cn, 0, chp - 1, dhp);
		}else if(chp == 1){
			ans = n + 1 - cn + dp(cn, cmp - 1, 0, dhp + 1);
		}else{
			ans = n + 1 - cn;
			int a1 = dp(cn, cmp - 1, chp - 2, dhp);
			int a2 = dp(cn, cmp - 1, chp - 1, dhp + 1);
			if(a1 < a2) ans += a1; else ans += a2;
		}
		//printf("dp %d %d %d %d = %d\n", cn, cmp, chp, dhp, ans);
	}
	return ans;
}

int main(){
	scanf("%d%d", &n, &m);
	f(i, 1, n) scanf("%d", a + i);
	std::sort(a + 1, a + n + 1);
	memset(_dp, 0xff, sizeof(_dp));
	printf("%d\n", dp(1, m, a[1], 0) - n);
	return 0;
}
